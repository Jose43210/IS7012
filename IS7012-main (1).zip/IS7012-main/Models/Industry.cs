using System.ComponentModel.DataAnnotations;

namespace RecruitCatUcUsername.Models
{
    public class Industry
    {
        public int Id { get; set; }


        // Additional properties
       [Required]
        [StringLength(100)]
        [Display(Name = "Industry Name")]
        public string Name { get; set; }

[StringLength(100)]
[Display(Name = "Sector")]
public string Sector { get; set; }
        [Display(Name = "Is Growing")]
public bool IsGrowing { get; set; }


        // Navigation
        public List<Candidate> Candidates { get; set; }
        public List<Company> Companies { get; set; }
    }
}
