using System;
using System.ComponentModel.DataAnnotations;

namespace RecruitCatUcUsername.Models
{
    public class Company
    {
        public int Id { get; set; }
        [Required]
[StringLength(100)]
[Display(Name = "Company Name")]
public string Name { get; set; }
        [Required]
[StringLength(100)]
[Display(Name = "Position Name")]
public string PositionName { get; set; }
      [Range(0, double.MaxValue)]
[Display(Name = "Minimum Salary")]
public decimal MinSalary { get; set; }

[Range(0, double.MaxValue)]
[Display(Name = "Maximum Salary")]
public decimal MaxSalary { get; set; }

  [DataType(DataType.Date)]
[Display(Name = "Start Date")]
public DateTime? StartDate { get; set; }

        [StringLength(500)]
[Display(Name = "Location")]
public string Location { get; set; }

        public decimal TargetSalary { get; set; }


        // Foreign Keys
        public int IndustryId { get; set; }
        public Industry Industry { get; set; }

        // Navigation
        public List<Candidate> Candidates { get; set; }

        // Additional properties
        public string Website { get; set; }
        public bool IsRemoteFriendly { get; set; }
        
    }
}
