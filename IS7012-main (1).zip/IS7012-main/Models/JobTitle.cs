using System.ComponentModel.DataAnnotations;

namespace RecruitCatUcUsername.Models
{
    public class JobTitle
    {
        public int Id { get; set; }
        [Required]
[StringLength(100)]
[Display(Name = "Job Title")]
public string Title { get; set; }
        [Range(0, double.MaxValue)]
[Display(Name = "Minimum Salary")]
public decimal MinSalary { get; set; }

[Range(0, double.MaxValue)]
[Display(Name = "Maximum Salary")]
public decimal MaxSalary { get; set; }

[StringLength(300)]
[Display(Name = "Required Skills")]
public string RequiredSkills { get; set; }
        // Additional properties[Range(1, 3)]
[Display(Name = "Experience Level")]
public int ExperienceLevel { get; set; } // 1 = Junior, 2 = Mid, 3 = Senior

        // Navigation
        public List<Candidate> Candidates { get; set; }
    }
}
