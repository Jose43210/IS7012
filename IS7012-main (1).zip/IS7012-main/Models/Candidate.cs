using System;
using System.ComponentModel.DataAnnotations;

namespace RecruitCatUcUsername.Models
{
    public class Candidate
    {
        public int Id { get; set; }
        [Required]
[StringLength(50)]
[Display(Name = "First Name")]
public string FirstName { get; set; }
        [Required]
[StringLength(50)]
[Display(Name = "Last Name")]
public string LastName { get; set; }
        [Range(0, double.MaxValue)]
[Display(Name = "Target Salary")]
public decimal TargetSalary { get; set; }
[DataType(DataType.Date)]
[Display(Name = "Start Date")]
public DateTime? StartDate { get; set; } // Nullable, no validation needed




        // Foreign Keys
        public int? CompanyId { get; set; }
        public Company Company { get; set; }

        public int JobTitleId { get; set; }
        public JobTitle JobTitle { get; set; }

        public int IndustryId { get; set; }
        public Industry Industry { get; set; }

        // Additional properties
        [Required]
[EmailAddress]
[StringLength(100)]
[Display(Name = "Email Address")]
        public string Email { get; set; }
    
        public bool IsAvailable { get; set; }






    }



}
