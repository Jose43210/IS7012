using Microsoft.EntityFrameworkCore;

namespace RecruitCatJoseEsquivel.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<RecruitCatUcUsername.Models.Candidate> Candidates { get; set; }
        public DbSet<RecruitCatUcUsername.Models.Company> Companies { get; set; }
        public DbSet<RecruitCatUcUsername.Models.Industry> Industries { get; set; }
        public DbSet<RecruitCatUcUsername.Models.JobTitle> JobTitles { get; set; }
    }
}


