using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RecruitCatJoseEsquivel.Data;
using RecruitCatUcUsername.Models;

namespace RecruitCatJoseEsquivel.Pages_Candidates
{
    public class DetailsModel : PageModel
    {
        private readonly RecruitCatJoseEsquivel.Data.ApplicationDbContext _context;

        public DetailsModel(RecruitCatJoseEsquivel.Data.ApplicationDbContext context)
        {

            _context = context;

        }
        public Company Company { get; set; }

        public Candidate Candidate { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }


            var candidate = await _context.Candidates.FirstOrDefaultAsync(m => m.Id == id);

            if (candidate is not null)
            {
                Candidate = candidate;

                return Page();
            }
            return NotFound();
        }
        
    }
}
